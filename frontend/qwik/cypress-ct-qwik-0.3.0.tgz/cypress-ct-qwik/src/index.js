export * from './lib/mount';
export * from './lib/add-qwik-loader';
//# sourceMappingURL=index.js.map