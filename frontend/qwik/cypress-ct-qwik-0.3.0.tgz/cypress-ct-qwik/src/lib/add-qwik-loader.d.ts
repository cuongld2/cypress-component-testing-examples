export declare function addQwikLoader(): void;
