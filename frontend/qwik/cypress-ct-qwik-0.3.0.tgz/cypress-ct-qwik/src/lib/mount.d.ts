import type { JSXNode, FunctionComponent } from '@builder.io/qwik';
export interface MountOptions {
    props?: Record<string, unknown>;
    options?: {
        strict?: boolean;
    };
}
type JSXOutput = JSXNode | string | number | boolean | null | undefined | JSXOutput[];
export declare function mount(component: JSXOutput | JSXNode[] | FunctionComponent<any>, options?: MountOptions): Cypress.Chainable<unknown>;
export {};
