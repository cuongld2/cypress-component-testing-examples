"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const cypress_1 = require("cypress");
const qwik = {
    type: 'qwik',
    name: 'Qwik',
    package: '@builder.io/qwik',
    installer: '@builder.io/qwik',
    description: 'The HTML-first framework',
    minVersion: '>0.19.2',
};
const qwikCity = {
    type: 'qwik-ct',
    name: 'Qwik City',
    package: '@builder.io/qwik-city',
    installer: '@builder.io/qwik-city',
    description: 'The meta-framework for Qwik',
    minVersion: '>0.4.0',
};
exports.default = (0, cypress_1.defineComponentFramework)({
    /**
     * This should match the `npm` package name.
     * The convention required to ensure your Definition is processed
     * by Cypress is `cypress-ct-*` for global packages, or
     * `@org/cypress-ct-*` for organization level packages.
     */
    type: 'cypress-ct-qwik',
    /**
     * The label that shows up when configuring Component Testing
     * for the first time.
     */
    name: 'Qwik',
    /**
     * Supported bundlers. Can be "webpack" and/or "vite".
     */
    supportedBundlers: ['vite'],
    /**
     * Used by Cypress to automatically detect the correct Framework Definition
     * based on the user's project.
     * In this example, if a module matching `solidDep`
     * is found in the user's project,
     * Solid.js will automatically be selected when configuring Component Testing.
     */
    detectors: [qwik],
    /**
     * Optionally, some conditional logic, based on whether
     * the user selected Vite or webpack.
     */
    dependencies: (bundler) => {
        return [qwik, qwikCity];
    },
    icon: `<svg style="height: auto; width: 100%" viewBox="0 0 52 60"
  fill="none" xmlns="http://www.w3.org/2000/svg">

  <path
    d="M40.973 52.5351L32.0861 43.6985L31.9503 43.7179V43.621L13.0511 24.9595L17.708 20.4637L14.9721 4.76715L1.99103 20.8513C-0.220992 23.0798 -0.628467 26.7036 0.962635 29.3778L9.07337 42.8265C10.3152 44.9 12.566 46.1402 14.9915 46.1208L19.0081 46.082L40.973 52.5351Z"
    fill="#18B6F6" />
  <path
    d="M45.8232 20.5411L44.038 17.2468L43.1066 15.5609L42.738 14.902L42.6992 14.9408L37.8094 6.47238C36.587 4.34075 34.2974 3.02301 31.8137 3.04239L27.5255 3.15865L14.7384 3.19741C12.313 3.21679 10.101 4.49577 8.87853 6.56927L1.09766 21.9945L15.0101 4.72831L33.2496 24.7656L30.0091 28.0406L31.9495 43.7178L31.9689 43.679V43.7178H31.9301L31.9689 43.7565L33.4824 45.2293L40.8364 52.4187C41.1469 52.7094 41.6514 52.3606 41.4379 51.9924L36.8975 43.0589L44.8142 28.4282L45.0664 28.1375C45.1634 28.0212 45.2604 27.905 45.3381 27.7887C46.8904 25.6764 47.1038 22.8472 45.8232 20.5411Z"
    fill="#AC7EF4" />
  <path
    d="M33.3076 24.6882L15.0099 4.74774L17.61 20.3668L12.9531 24.882L31.9105 43.6985L30.203 28.0794L33.3076 24.6882Z"
    fill="white" />
</svg>`
});
//# sourceMappingURL=definition.js.map